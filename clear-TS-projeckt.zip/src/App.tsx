import GlobalStyles from "./styles/GlobalStyles";

function App() {
  return (
    <GlobalStyles />
      
  );
}

export default App;
